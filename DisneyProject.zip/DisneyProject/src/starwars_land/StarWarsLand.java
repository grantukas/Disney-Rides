package starwars_land;

public class StarWarsLand {

	public static void main(String[] args) {
		BantuuCantina bantuuCantina = new BantuuCantina();
		firstOrderBattleEscape rideEscape = new firstOrderBattleEscape();
		MilleniumFalcon ride = new MilleniumFalcon();
		
		System.out.println("---First you stop by the First Order Battle Escape ride---");
		rideEscape.rideBattleEscape();
		
		System.out.println("---You just got really hungry and stop by the Bantuu Cantina food stand---");
		bantuuCantina.orderBantuuCantina();
		
		System.out.println("---Next you decide to ride the Millenium Falcon---");
		ride.RideMillenium();

		

	}

}
