package starwars_land;
//melody
import java.util.Scanner;
import java.util.Random;

public class firstOrderBattleEscape {
	
	public void rideBattleEscape() {
	
	Random rand = new Random();
	
	Scanner keyboard = new Scanner(System.in);
	
	int allegience;
	int waitTime = rand.nextInt(120)+5;
	
	
	System.out.println("hello");
	System.out.println("The current wait time for the First Order Battle Escape is "+ waitTime + " minutes.");
	System.out.println("You. Yeah you, in the ridiculous looking hat.\nAre you a resistence sympathizer, or a first order soldier. \nEnter 0 if you scrounge with rebel scum, or 1 if you are loyal to our cause.");
	allegience = keyboard.nextInt();
	if(allegience == 0){
		System.out.println("You are. Perfect. I'm an undercover resistance officer.\nWe're trying to overtake this First Order base, follow me.\nShoot, stormtroopers. Get in this transport, and your R2 unit will lead you to the command center.\nOnce you're there, you need to enter this disc into their base drive.\nThat should override the command center and give us control. You ready?\n\"You ride the ride and the Resistance is victorious!\n\"");
	}
	else if(allegience == 1){	
		System.out.println("Smart answer. Kylo Ren needs to snuff out the resistance spies from our base.\nFollow me onto this transport, where an R2 unit will guide you to their hideout.\nOnce you're there, your R2 unit will disable their clearanced, and those scum will be sent straight to Snoke's chambers.\n\"You ride the ride, capture the resistance, and bring glory to the First order.\n\"");
	}
		
		
	
	
	}
	

}
