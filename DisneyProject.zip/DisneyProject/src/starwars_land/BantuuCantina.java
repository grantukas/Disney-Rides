package starwars_land;
//irene

import java.util.Scanner;

public class BantuuCantina {
	
	private int blueMilkAmount = 100;
	private int rootLeafStewAmount = 200;
	private int flatbreadAmount = 300;
	
	private double blueMilkPrice = 5.00;
	private double rootLeafStewPrice = 15.00;
	private double flatbreadPrice = 10.00;

	
	public void orderBantuuCantina() {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("\nHi welcome to Bantuu Cantina \n"
				+ "What would you like to order we have: \n"  +
				blueMilkAmount + " Blue Milk(s), \n" +
				rootLeafStewAmount + " Root Leaf Stew(s),\n" +
				flatbreadAmount + " Flatbread(s) \n" +
				"Please enter '1' for Blue Milk, '2' for Root Leaf Stew or '3' for Flatbread. \n" +
				"Due to the grand opening, you can only order one item.\n");
		
		System.out.println("What would you like to order? ");
		int order = keyboard.nextInt();
		
		if (order == 1){
			System.out.println("The price of Blue Milk is: $" + blueMilkPrice);
			boolean checkMilk = hasblueMilk(1);
			
			if (checkMilk = true) { blueMilkAmount --;
			System.out.println("Here is your Blue milk...");}
			else { System.out.println("We sold out of Blue Milk.");}
			}
		
		else if (order == 2){
			System.out.println("The price of Root Leaf Stew is: $" + rootLeafStewPrice);
			
			boolean checkStew = hasrootLeafStew(1);
			if (checkStew = true) { rootLeafStewAmount --; 
			System.out.println("Here is your Root Leaf Stew...");}
			else {System.out.println("We sold out of Root Leaf Stew.");}
			}
				
		else if (order == 3){
			System.out.println("The price of Flatbreads is: $" + flatbreadPrice);
			boolean checkBread = hasflatbread(1);
			
			if (checkBread = true) { flatbreadAmount --;
			System.out.println("Here is your Flatbread...");}
			
			else {System.out.println("We sold out of Flatbread."); }
				}
			}
	
	
	private boolean hasblueMilk(double amountToBeDeducted) {
		if ( (blueMilkAmount-amountToBeDeducted) > 0) { return true; }
		else {return false;}
		}
	
	private boolean hasrootLeafStew(double amountToBeDeducted) {
		if ( (rootLeafStewAmount-amountToBeDeducted) > 0) {return true;}
		else {return false;}
		}
	
	private boolean hasflatbread(double amountToBeDeducted) {
		if ( (flatbreadAmount-amountToBeDeducted) > 0) {	return true;}
		else { return false;}
		}
}
