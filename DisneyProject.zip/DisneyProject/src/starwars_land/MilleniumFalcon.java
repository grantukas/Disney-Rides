package starwars_land;
//noah
import java.util.Random;
import java.util.Scanner;

public class MilleniumFalcon {
	
	public void RideMillenium(){
		System.out.println("Welcome to the ride");
		Scanner myscanner = new Scanner(System.in);
		System.out.println("How many are here?");
		int passengers = myscanner.nextInt();
		passengers = size(passengers);
		int setting = 0;
		setting =setting(setting);
		boolean performance;
		if (setting%2 <= 0);{
		performance = true;}
		if (setting%2 >= 0);{
		performance = false;}
		performance = BountyHunter(performance);
		performance = reputation(performance);
		
	}
	
	static Random rand = new Random();
	
	public static int size(int passengers) {
		if (passengers > 8);
		passengers = 8;
		return passengers;
	}
		public static boolean BountyHunter(boolean performance) {
		if (performance) {
		return true;
		}
		else {
			System.out.println("You're not getting out of here alive!");
		return false;
				}
		}
		private static int setting(int setting) {
			setting = rand.nextInt(12) + 1;
			return setting;
		}

		public static boolean reputation(boolean performance) {
			if (performance) {
				System.out.println("Good Job Kid");
				return true;
				}
			
			else {
				System.out.println("They won't forget that");
				return false;
				}
		}
		}
			


