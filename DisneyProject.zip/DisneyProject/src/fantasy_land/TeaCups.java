package fantasy_land;
import java.util.Scanner;

public class TeaCups {

		Scanner keyboard = new Scanner(System.in);
		
		private String name;
		
		public TeaCups() {
		}
		
		public void enterRide() {
			System.out.println("\nWelcome to the Tea Cups!");
			System.out.println("Are you okay with a spinning ride? (Enter y or n)");
			spin();
		}
		
		public void spin() {
			String choice = null;
			choice = keyboard.nextLine();
			
			if(choice.equals("y")) {
				System.out.println("\nExcellent! Choose any color tea cup and climb in!");
				System.out.println("Four guests per cup only please! Enjoy the ride!");
				System.out.println("\nWhen the tea cups come to a full stop open the door and exit to your right!");
				System.out.println("Have a fun day in Wonderland!");
			}
			else {
				System.out.println("\nWe have other non-spinning options that might be better!");
				System.out.println("I hope you have a magical day!");
			}
			
		}
	}


