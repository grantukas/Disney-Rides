package fantasy_land;
import java.util.Scanner;

public class Fantasyland {
	Scanner keyboard = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		
		Characters belle = new Characters("Belle");
		Characters cinder = new Characters("Cinderella");
		Characters snow = new Characters("Snow White");
		
		belle.sayHi("Belle");
		
		ChurroStand churros = new ChurroStand(10);
		churros.makeChurros();
		churros.giveChurros();
		
		cinder.sayHi("Cinderella");
		
		TeaCups ride = new TeaCups();
		ride.enterRide();
		
		snow.sayHi("Snow White");
		
		System.out.println("Thank you for visiting FantasyLand!");
		
			
	}
	

}
