package fantasy_land;
import java.util.Scanner;

public class ChurroStand {
	Scanner keyboard = new Scanner(System.in);



	private int totalChurros;

	private int minChurros = 0;

	

	public ChurroStand(int totalChurros) {

		System.out.println("\nThere are currently " + totalChurros + " churros available");

	}

	

	public void makeChurros() {

		System.out.println("\nLet's make some more churros! How many would you like to make?");

		int addChurro = keyboard.nextInt(); 

		totalChurros += addChurro;

	}

		

	public void giveChurros() {

		System.out.println("\nLet's eat some churros! How many would you like?");

		int deleteChurro = keyboard.nextInt(); 

		if (standHasEnoughChurros(deleteChurro)) {

			totalChurros -= deleteChurro;

			System.out.println("YUM");

		}

	}

	public boolean standHasEnoughChurros(int amount) {

		if ((totalChurros - amount) > minChurros) {

			return true;

		}
		else
		{
		System.out.println("\nChurros sold out! :( ");

		return false;
		}
	}

}

