package fantasy_land;

import java.util.Scanner;

public class Characters {
	Scanner keyboard = new Scanner(System.in);

	private String name;
	
	public Characters(String myName)
	{
		name = myName;
	}
	
	public void sayHi(String myName)
	{		
		System.out.println("\nHi! I'm Princess " + myName + "! It is lovely to see you today!");
		System.out.println("\nShall we take a photo? (Enter yes or no)");
		takePhoto();
	}
	
	public void takePhoto()
	{
		String choice = null;
		choice = keyboard.nextLine();
		
		if (choice.equals("yes"))
		{
			System.out.println("\nWonderful! Say cheese!");
			System.out.println("\n*Click*");
			System.out.println("\nHave a Magical Day!");
		}
		else
		{
			System.out.println("\nOh! Well I hope your day is Magical!");
		}
		
	}

}
