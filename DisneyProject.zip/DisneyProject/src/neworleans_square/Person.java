package neworleans_square;

public class Person {
	
	private String name;
	private double money;
	private static int age;
	public String userSouveniers;
	
	public Person(String myName, int myAge, double myMoney) {
		name = myName;
		age = myAge;
		money = myMoney;
		userSouveniers = "";
		
	}
	
	public void getMoney(double cash) {
		money += cash;
		System.out.println("Your total balance is now: $" + money);
	}
	
	public void spendMoney(double amount) {
		if (money < amount) {
			System.out.println("Insufficient Funds");
		}
		else {
			money -= amount;
			System.out.println("Your total balance is now: $" + money);
		}
	}
	
	public static boolean ageCheck() {
		if (age < 21) {
			return false;
		}
		else {
			return true;
		}
	}
	public void getSouveniers() {
		System.out.println(userSouveniers);
	}
	
	

}
