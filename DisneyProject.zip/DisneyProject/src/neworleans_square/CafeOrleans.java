package neworleans_square;

public class CafeOrleans {
	
	private static double runningTotal = 0;
	private static double beniersCost = 5.00;
	private static double bagelCost = 3.50;
	private static double coffeeCost = 3.00;
	private static double waterCost = 2.50;
	
	//returns menu and prices
	public static void checkMenu(boolean check) {
		if (check == true) {
			System.out.println("Welcome to Cafe Orleans!");
			System.out.println("Beniers cost $"+ beniersCost);
			System.out.println("Bagels cost $" + bagelCost);
			System.out.println("Coffee costs $" + coffeeCost);
			System.out.println("Water costs $" + waterCost);
		}
		else {
		}
	}

	//takes in persons money and choice, adds cost to check and returns price
	public static void purchaseItem(String choice) {
		if (choice.equals("beniers")) {
			System.out.println("You buy some beniers. Theyre quite yummy wummy in your tummy");
			runningTotal += beniersCost;
		}
		else if (choice.equals("bagel")) {
			System.out.println("You buy a bagel. Fresh and kosher");
			runningTotal += bagelCost;
		}
		else if (choice.equals("coffee")) {
			System.out.println("You buy some coffee. Hot and energizing");
			runningTotal += coffeeCost;
		} 
		else if (choice.equals("water")) {
			System.out.println("You buy some water. You just spent 2.50 on water you fool!");
			runningTotal += waterCost;
		}
		else {
		}
	}
		
	//prints meal cost and returns running total
	public static double checkPlease() {
		System.out.println("The total cost is: $" + runningTotal);
		return runningTotal;
	}

}
