package neworleans_square;

public class BlueBayouResturant {
	
	private double runningTotal = 0;
	private double ribsCost = 25.00;
	private double jambalayaCost = 20.00;
	private double sodaCost = 3.00;
	private double pieCost = 8.50;
	private double cocktailCost = 7.50;
	
	//returns menu and prices
	public void checkMenu() {
		System.out.println("");
		System.out.println("Welcome to the Blue Bayou Resturant!");
		System.out.println("- Our delicious Buccaneers Boneless Beef Short Ribs cost $"+ ribsCost);
		System.out.println("- The speciality Cajun Seafood Jambalaya costs $" + jambalayaCost);
		System.out.println("- The sweet Homemade Pecan Pie costs $" + pieCost);
		System.out.println("- A soda or specialty drink costs $" + sodaCost);
		System.out.println("- Any cocktail from our bar costs $" + cocktailCost);
		System.out.println("(Unfortunately we do not offer any vegan options here at the Blue Bayou)");
		System.out.println("");
	}
	
	//takes in persons money and choice, adds cost to check and returns price
	//valid inputs are "ribs", "jambalaya", "soda", "pie", and "cocktail"
	public void purchaseItem(String choice) {
		if (choice.equals("ribs")) {
			System.out.println("You order some ribs. They're glazed with sweet cajun BBQ sauce.");
			System.out.println("You feel the contentment that only ribs can provide");
			runningTotal += ribsCost;
		}
		else if (choice.equals("jambalaya")) {
			System.out.println("You order the jambalaya. The seasoning invigorating - the texture divine");
			runningTotal += jambalayaCost;
		}
		else if (choice.equals("pie")) {
			System.out.println("You order a slice of the pie. Even before it reaches your table the smell hits");
			System.out.println("While your waistline may not agree, this was the right choice");
			runningTotal += pieCost;
		}
		else if (choice.equals("cocktail")) {
			
			//running check age function
			if (Person.ageCheck() == true) {
			System.out.println("You feel saucy and order a cocktail. It's one of the tropical ones with the little umbrellas");
			runningTotal += cocktailCost;
			}
			
			else {
			System.out.println("You try to buy a cocktail however, you must be 21 to buy cocktails");
			System.out.println("Maybe try a soda instead kiddo");
			}
		} 
		
		else if (choice.equals("soda")) {
			System.out.println("You buy some soda. You just spent 3.00 on soda you fool!");
			runningTotal += sodaCost;
		}
		else {
		}
	}
		
	//prints meal cost and returns running total
	public double checkPlease() {
		System.out.println("The total cost is: $"+runningTotal);
		return runningTotal;
	}

}
