package neworleans_square;


public class ATM {
	
	private double machineBalance;
	
	public ATM () {
		machineBalance = 500;
	}
		//checks to see if transaction is 
		public double withdrawMoney(double money,boolean choice){
			
			if (money > machineBalance) {
				System.out.println("Sorry, this machine does not have enough funds to complete your transaction");
				return 0;
			}
			
			else {
				System.out.println("Transaction approved - thank you for your patronage!");
				machineBalance -= money;
				askReceipt(money,choice);
				return money;
			}
		}
		
		//prints receipt if boolean choice is true
		private void askReceipt(double money, boolean choice) {
			
			System.out.println("Would you like a receipt?");
			
			if (choice == true) {
				System.out.println("'Yes please'");
				System.out.println("Your total comes out to $" + money + ". Have a good day!");
			}
			else {
			}
		}

}
