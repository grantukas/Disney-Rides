package neworleans_square;
import java.util.Random;

public class HauntedHouse {
	
	private Random numGen = new Random();
	private final double ticketCost = 15.00;
	private static boolean ticket = false;
	
	//
	public double buyTicket() {
		System.out.println("Thank you for purchasing a ticket and welcome to the haunted mansion!");
		ticket = true;
		return ticketCost;
	}
	
	//randomized spot in line
	//if wait time exceeds limit, person leaves
	//else calls go in mansion method
	public void waitInLine() {
		
		
		//x is random int between 1 and 10
		//if waiting in line for longer than 6 spots, person gets fed up and leaves
		int counter = 0;
		for (int x = numGen.nextInt(10)+1; x > -1; x --) {
			counter ++;
			
			//checks how long wait has been
			if (counter >= 7) {
				System.out.println("You get fed up with waiting in line and go somewhere else");
				break;
			}
			
			else if (x == 0) {
				System.out.println("It's your turn to enter the mansion!");
				System.out.println("");
				goInMansion(ticket);
			}
			else {
				System.out.println("You are "+x+" people from the front of the line");
				continue;
			}
		}
	}
	
	//checks for ticket
	//if ticket is present begins wall-of-text mansion adventure
	//else spits person back out
	private void goInMansion(boolean ticket) {
		
		System.out.println("Welcome to the haunted mansion! Tickets please.");
		
		if (ticket = true) {
			
			//takes ticket
			ticket = false;
			
			System.out.println("Thank you for the ticket! Right this way, sir");
			System.out.println("");
			System.out.println("You enter the Doom Buggy and prepare to meet your fate");
			System.out.println("You begin slowly moving along a track as spooky spectres dance all around");
			System.out.println("Your ghost host shows you the way as you move bewteen the maze-like rooms");
			System.out.println("The gloomy atmosphere is quite alarming");
			System.out.println("Just as you can't take it any longer, the car exits the mansion and you're back where you started");
			System.out.println("");
			System.out.println("Thank you for riding the Doom Buggy in the haunted mansion!");
			System.out.println("Come again soon!");
		}
		else {
			System.out.println("Sorry sir, you don't seem to have a ticket, please buy one from the window then come back");
		}
	}
	
}


