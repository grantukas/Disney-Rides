package neworleans_square;

public class NewOrleansSquare {
	
	public static void main(String[] args) {
		Person guy = new Person("Guy", 18, 30);
		
		System.out.println("Welcome to New Orleans Square!");
		System.out.println("First we'll go to the cafe to get some food and a drink.");
		System.out.println();
		
		CafeOrleans.checkMenu(true);
		CafeOrleans.purchaseItem("bagel");
		CafeOrleans.purchaseItem("beniers");
		CafeOrleans.purchaseItem("coffee");
		guy.spendMoney(CafeOrleans.checkPlease());
		
		HauntedHouse house = new HauntedHouse();
		System.out.println();
		System.out.println("That was some tasty food! Now lets go on a ride! Get in line to get a ticket for the haunted mansion");
		System.out.println("Looks like you've made it to the front of the line. Time to buy your ticket.");
		guy.spendMoney(house.buyTicket());
		System.out.println();
		house.waitInLine();
			
		ATM boa = new ATM();
		System.out.println();
		System.out.println("Looks like your running out of money. Go get some from the ATM");
		guy.getMoney(boa.withdrawMoney(60, true));
		
		
		BlueBayouResturant blue = new BlueBayouResturant();
		System.out.println();
		System.out.println("Looks like your getting hungry again. You should go to the Blue Bayou Resturant and get some dinner.");
		blue.checkMenu();
		blue.purchaseItem("ribs");
		blue.purchaseItem("jambalaya");
		blue.purchaseItem("cocktail");
		guy.spendMoney(blue.checkPlease());
		
		System.out.println();
		System.out.println("Thank you for coming to New Orleans Square! Hope to see you again soon!");
	}

}
