package tomorrow_land;

public class World {
	public static void main(String[] args) {
		spaceMountain rideSpace = new spaceMountain();
		ReddRockettsPizza eatRedd = new ReddRockettsPizza();
		Inventions rideInventions = new Inventions();
		StarWars rideStar = new StarWars(); //Should be Star Tours not Star Wars
		
		int userExcitement = 0;
		String userSouveniers = "";
		
		System.out.println();
		//System.out.println("Ride Space Mountain!" + rideSpace.rideSpaceMountain());
		//System.out.println("You want a souvenier " + rideSpace.getSouvenier());
		
		System.out.println();		
		System.out.println("You are hungry.");
		System.out.println("You eat Redd Rocketts Pizza for " + eatRedd.purchase(1));
		
		System.out.println();		
		System.out.println("You want to ride Inventions");
		System.out.println(rideInventions.ride());
		rideInventions.souvenir();
		
		System.out.println();
		System.out.println("You want to ride Star Tours");
		rideStar.rideStarTours();
		rideStar.getSouvenier();
		
	}
}
