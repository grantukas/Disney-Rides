package adventure_land;
public class Character{
	private String characterName;
	private boolean good;
	private String movie;
	private boolean mainCharacter;
	
	public Character(String name, boolean alignmentGood, String movieParam, boolean mainCharacterBool) {
		characterName = name;
		good = alignmentGood;
		movie = movieParam;
		mainCharacter = mainCharacterBool;
	}
	
	public void switchAlignment() {
		good = !good;
	}
	
	public String getCharacterName() { return characterName; }
	public boolean getAlignment() { return good; }
	public String getCharacterMovie() { return movie; }
	public boolean getIsMainCharacter() { return mainCharacter; }
}