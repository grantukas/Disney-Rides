package adventure_land;

public class FoodStall {
	private String FoodStallName = "Bengal Barbecue";
	private boolean VegetarianOptions;
	
	public FoodStall (String Name, boolean Vegetarian) {
		FoodStallName = Name;
		VegetarianOptions = Vegetarian;
		
	}
	public String getName() {
		return FoodStallName;
	}
	public boolean VegetarianOptions() {
		return VegetarianOptions;
	}
	
}
