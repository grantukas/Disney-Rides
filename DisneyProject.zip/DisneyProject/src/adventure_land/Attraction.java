package adventure_land;
//Created by Matt McCortney -- Team D
public class Attraction {
	private String attractionName;
	private boolean wheelchairAccessible;
	private int waitTimeMinutes;
	private int rideLengthMinutes;
	private int minimumHeightInches;
	private int maximumHeightInches;
	
	//Constructor
	public Attraction(String name, boolean wheelchairFriendly, int rideLength) {
		attractionName = name;
		wheelchairAccessible = wheelchairFriendly;
		rideLengthMinutes = rideLength;
		waitTimeMinutes = 0;
		minimumHeightInches = 0;
		maximumHeightInches = 0;
	}
	
	//Modifiers
	public void setWaitTime(int minutes) {
		waitTimeMinutes = minutes;
	}	
	
	public void setMinimumHeight(int inches) {
		minimumHeightInches = inches;
	}
	
	public void setMaximumHeight(int inches) {
		maximumHeightInches = inches;
	}
	
	public boolean isBusy() {
		boolean busy;
		
		if (waitTimeMinutes > 0) {
			busy = true;
		} else {
			busy = false;
		}
		
		return busy;
	}
	
	//Might come in handy.
	/*private double calculateRidesPerHour() {
		return 60.0 / (double) rideLengthMinutes;
	}*/
	
	//Accessors
	public String getAttractionName() { return attractionName; }
	public boolean getWheelchairInfo() { return wheelchairAccessible; }
	public int getWaitTime() { return waitTimeMinutes; }
	public int getRideLength() { return rideLengthMinutes; }
	public int getMinimumHeight() { return minimumHeightInches; }
	public int getMaximumHeight() { return maximumHeightInches; }
}
