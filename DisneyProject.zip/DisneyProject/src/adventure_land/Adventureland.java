package adventure_land;

public class Adventureland {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Attractions
		Attraction tikiRoomAttr = new Attraction("Enchanted Tiki Room", true, 4);
		Attraction jungleCruiseAttr = new Attraction("Jungle Cruise", true, 5);
		Attraction indianaJonesAttr = new Attraction("Indiana Jones Adventure", false, 3);
		Attraction tarzansTreehouseAttra = new Attraction("Tarzan's Treehouse", false, 5);
		
		//Characters
		Character indianaJonesCharacter = new Character("Indiana Jones", true, "Raiders of the Lost Ark", true);
		Character tarzanCharacter = new Character("Tarzan", true, "Tarzan", true);
		Character janeCharacter = new Character("Jane", true, "Tarzan", true);
		
		//Food stalls
		FoodStall prezelStall = new FoodStall("Pretzels", true);
		FoodStall burgerStall = new FoodStall("Burgers", false);
		FoodStall cottenCandyStall = new FoodStall("Cotton Candy", true);
		FoodStall iceCreamStall = new FoodStall("Ice Cream", true);
		FoodStall churroStall = new FoodStall("Churros", true);
	}

}
